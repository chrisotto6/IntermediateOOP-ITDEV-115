﻿/*************************
 * Christopher Otto
 * File IO/Trivia Game
 * Spring 2014, ITDEV-115
 **************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace FileIO
{
    class TriviaUI
    {
        private QuestionBank Questions = new QuestionBank();

        public void DisplayWelcome()
        {
            Console.WriteLine("Welcome to the Brewer's Trivia Game!!!");
            Console.WriteLine("");
            Console.WriteLine("Good Luck!");
            Console.WriteLine("");
        }

        public void Play()
        {
            int num = 0;
            int num1 = 0;
            string[] strArrays = new string[4];
            char[] chr = new char[] { Convert.ToChar(",") };
            int num2 = 0;
            this.DisplayWelcome();
            this.Questions.ReadQuestionFile("Questions.txt");
            while (num2 < this.Questions.GetNumberofQuestions)
            {
                Console.WriteLine(this.Questions.GETQuestion(num2));
                strArrays = this.Questions.GETAnswer(num2).Split(chr);
                Console.WriteLine(string.Concat("A.) ", strArrays[0]));
                Console.WriteLine(string.Concat("B.) ", strArrays[1]));
                Console.WriteLine(string.Concat("C.) ", strArrays[2]));
                Console.WriteLine(string.Concat("D.) ", strArrays[3]));
                if (!(this.PromptforGuess() == this.Questions.GETCorrectAnswer(num2)))
                {
                    num1++;
                    Console.WriteLine(string.Concat("Incorrect, ", this.Questions.GETExplanation(num2)));
                    Console.WriteLine();
                }
                else
                {
                    num++;
                    Console.WriteLine("Correct");
                    Console.WriteLine();
                }
                num2++;
            }
            Console.WriteLine("");
            Console.WriteLine(string.Concat("Total Questions: ", num + num1));
            Console.WriteLine(string.Concat("Correct Answers: ", num));
            Console.WriteLine(string.Concat("Incorrect Answers: ", num1));
            Console.WriteLine("");
            Console.WriteLine("Press any key to continue.");
            Console.ReadLine();
        }

        public void PlayAgain()
        {
            string upper = "Y";
            do
            {
                this.Play();
                Console.WriteLine("Do you want to try again? Enter Y or N");
                upper = Console.ReadLine();
                if (upper.Length > 0)
                {
                    upper = upper.Substring(0, 1);
                }
                upper = upper.ToUpper();
            }
            while (upper == "Y");
        }

        public string PromptforGuess()
        {
            Console.WriteLine("Select A - D");
            string upper = Console.ReadLine();
            if (upper != null)
            {
                upper = upper.Substring(0).ToUpper();
            }
            return upper;
        }
    }
}
