﻿/*************************
 * Christopher Otto
 * File IO/Trivia Game
 * Spring 2014, ITDEV-115
 **************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace FileIO
{
    class Program
    {
        static void Main(string[] args)
        {
            Info myInfo = new Info();
            myInfo.DisplayInfo("Assignment 6 - File IO, Trivia Game");
            (new TriviaUI()).PlayAgain();
        }
    }
}
