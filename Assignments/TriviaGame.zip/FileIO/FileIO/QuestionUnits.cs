﻿/*************************
 * Christopher Otto
 * File IO/Trivia Game
 * Spring 2014, ITDEV-115
 **************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace FileIO
{
    class QuestionUnits
    {
         private string m_Answers;

        private string m_CorrectAnswer;

        private string m_Explanation;

        private string m_Questions;

        public string Answer
        {
            get
            {
                return this.m_Answers;
            }
            set
            {
                this.m_Answers = value;
            }
        }

        public string CorrectAnswer
        {
            get
            {
                return this.m_CorrectAnswer;
            }
            set
            {
                this.m_CorrectAnswer = value;
            }
        }

        public string Explanation
        {
            get
            {
                return this.m_Explanation;
            }
            set
            {
                this.m_Explanation = value;
            }
        }

        public string Question
        {
            get
            {
                return this.m_Questions;
            }
            set
            {
                this.m_Questions = value;
            }
        }

    }
}
