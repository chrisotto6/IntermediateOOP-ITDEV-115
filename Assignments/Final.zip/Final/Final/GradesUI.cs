﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/******************************
 * Student: Christopher Otto
 * Purpose: GradesUI - Handles Console logic
 ************************************/

namespace Final
{
    class GradesUI
    {
        StudentS myStudentS;

        public void MainMethod()
        {
            myStudentS = new StudentS();

            try
            {
                myStudentS.PopulateStudents();
                DisplayInfo();
                Console.ReadLine();
            }
            catch
            {
                Console.WriteLine("Exception caught and handled.");
            }
          
        }

        void DisplayInfo()
        {
            Console.WriteLine("Student id\tLast Name\tAverage  \tGrade");

            for (int index = 0; index < myStudentS.ListLength; index++)
            {

                Console.WriteLine(" {0} \t {1}    \t {2}    \t {3}", myStudentS.StudentID(index), myStudentS.StudentLastName(index), myStudentS.StudentAverage(index), myStudentS.StudentGrade(index));
            }
        }
    }
}
