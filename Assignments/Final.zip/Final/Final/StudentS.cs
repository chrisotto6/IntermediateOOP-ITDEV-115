﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO; //add for file io.
using System.Collections;  //for List..

/******************************
 * Student: Christopher Otto
 * Purpose: Students Class - hold List of Students
 ************************************/

namespace Final
{
    class StudentS
    {
        List<Student> theStudentList;
        
     
       
        public void PopulateStudents()   
        {
            theStudentList = new List<Student>();

            FileInfo theSourceFile = new FileInfo("Grades.txt");
            string line;
            string[] fields;
            char[] delimiter = {System.Convert.ToChar(",")};
            Student aStudent;

            try
            {
                StreamReader thereader = theSourceFile.OpenText();

                line = thereader.ReadLine();

                while (line != null)
                {
                    aStudent = new Student();
                    
                    fields = line.Split(delimiter);

                    aStudent.ID = fields[0];
                    aStudent.NameFirst = fields[1];
                    aStudent.NameLast = fields[2];

                    for (int i = 3; i <= 23; i++)
                    {
                        int earned = Convert.ToInt32(fields[i]);
                        i++;
                        int possible = Convert.ToInt32(fields[i]);

                        aStudent.EnterGrade(earned, possible);
                    }

                    aStudent.CalGrade();

                    theStudentList.Add(aStudent);

                    line = thereader.ReadLine();
                } 


            }
            catch
            {
                Console.WriteLine("Exception caught and Handled ");
            }
     
        }
        public int ListLength
        {
            get { return theStudentList.Count; }
        }

        public string StudentID(int index)
        {
            return theStudentList.ElementAt(index).ID;
        }
        public string StudentLastName(int index)
        {
            return theStudentList.ElementAt(index).NameLast;
        }

        public string StudentGrade(int index)
        {

            theStudentList.ElementAt(index).CalGrade();
            return theStudentList.ElementAt(index).LetterGrade;
        }

        public float StudentAverage(int index)
        {
            theStudentList.ElementAt(index).CalGrade();
            return theStudentList.ElementAt(index).Average;
        }
    }
}
