﻿/*************************
 * Christopher Otto
 * Tic Tac Toe
 * Info Class, Displays student information
 * Spring 2014, ITDEV-115
 **************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToe
{
    class Info
    {
        public void DisplayInfo(string assignName)
        {
            Console.WriteLine("******************************************************");
            Console.WriteLine("Name      : Chris Otto ");
            Console.WriteLine("Assignment: " + assignName);
            Console.WriteLine("Instructor: Judy Ligocki");
            Console.WriteLine("Date      : " + DateTime.Now.ToShortDateString());
            Console.WriteLine("******************************************************");
        }
    }
}
