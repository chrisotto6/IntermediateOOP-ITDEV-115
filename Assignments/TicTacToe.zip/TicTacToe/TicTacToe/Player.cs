﻿/*************************
 * Christopher Otto
 * Tic Tac Toe
 * Player Class, handles all the player code
 * Spring 2014, ITDEV-115
 **************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TicTacToe
{
    class Player
    {
        const int NUM_PIECES = 2;
        char[] PIECES = { 'X', 'O' };
        static int current = 0;
        char m_Piece;

        public Player() // Defines the player
        {
            m_Piece = PIECES[current];
            current = (current + 1) % NUM_PIECES; //toggles between the players, X and O
        }

        public char Piece //getter for piece
        {
            get { return m_Piece; }
        }

        public void MakeMove(ref Board aBoard, int move)  //makes the move of the user
        {
            aBoard.ReceiveMove(m_Piece, move);
        }
    }
}
