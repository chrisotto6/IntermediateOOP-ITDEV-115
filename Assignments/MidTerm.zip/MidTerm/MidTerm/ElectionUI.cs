﻿/*************************
 * Christopher Otto
 * MidTerm
 * ElectionUI Class handles front end processes with the User
 * Spring 2014, ITDEV-115
 **************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MidTerm
{
    class ElectionUI
    {
        //Creates new election
        Election theElection = new Election();

        int PromptForInt(string prompt) //Prompt gets the int for the number of votes
        {
            int num;
            Console.Write(prompt + ": ");
            int.TryParse(Console.ReadLine(), out num);
            return num;
        }

        string PromptForString(string prompt) //Prompt gets the string for the name
        {
            Console.Write(prompt + ": ");
            return Console.ReadLine();
        }

        public void MainMethod() //Main runs the prompts for the candidate and their votes calls display results
        {
            for (int i = 0; i < this.theElection.NumberOfCandidates; i++)
            {
                string name = this.PromptForString("Enter the Name of the Candidate");
                int numOfVotes = this.PromptForInt("Enter the number of votes for " + name);
                Console.WriteLine(""); //Separates the candidates, easier to read
                this.theElection.SetCandidateName(name, i);
                this.theElection.SetCandidateVotes(numOfVotes, i);
            }
            this.DisplayResults();
            Console.ReadLine();
        }

        void DisplayResults() //Goes Through and displays the results, put in a tab order for output to make it easier for reader to see
        {
            int winner = 0;
            int votes = 0;

            votes = this.theElection.TotalVotes();
            winner = this.theElection.FindWinner();

            for (int i = 0; i < this.theElection.NumberOfCandidates; i++)
            {
                Console.WriteLine("{0}\t{1}\t{2}",this.theElection.GetCandidateName(i),this.theElection.GetCandidateVotes(i),(((float)this.theElection.GetCandidateVotes(i)) / ((float)votes)).ToString("P2"));
            }
            Console.WriteLine("");
            Console.WriteLine("The Winner of this election is...." + this.theElection.GetCandidateName(winner) + "!!!!");
        }
    }
}
