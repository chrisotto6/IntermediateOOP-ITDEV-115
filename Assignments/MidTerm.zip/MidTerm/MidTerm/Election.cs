﻿/*************************
 * Christopher Otto
 * MidTerm
 * Election Class handles the back end processes of the election application
 * Spring 2014, ITDEV-115
 **************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MidTerm
{
    class Election
    {
        //Data Members
        private string[] candidatesName = new string[5];
        private int[] votes = new int[5];
        private const int numOfCandidates = 5; 

        //Methods
        public void SetCandidateVotes(int numOfVotes, int value) //Set the number of votes the candidate received
        {
            if (value < 5)
            {
                this.votes[value] = numOfVotes;
            }
        }

        public int GetCandidateVotes(int value) //Returns the votes that the candidate received
        {
            return this.votes[value];
        }

        public void SetCandidateName(string name, int value) //Sets the name of the candidate
        {
            if (value < 5)
            {
                this.candidatesName[value] = name;
            }
        }

        public string GetCandidateName(int value) //Returns the name of the candidate
        {
            return this.candidatesName[value];
        }

        public int FindWinner() //Finds the winner of the election
        {
            int index = 0;
            for (int i = 0; i < 5; i++)
            {
                if (this.votes[i] > this.votes[index])
                {
                    index = i;
                }
            }
            return index;
        }
        
        public int TotalVotes()
        {
            int num = 0;
            for (int i =0; i < 5; i++)
            {
                num += this.votes[i];
            }
            return num;
        }

        //Election Properties
        public int NumberOfCandidates
        {
            get
            {
                return 5;
            }
        }
    }
}
