﻿/*************************
 * Christopher Otto
 * MidTerm
 * Calls the Info and starts a new election process through ElectionUI's Main Method
 * Spring 2014, ITDEV-115
 **************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MidTerm
{
    class Program
    {
        static void Main(string[] args)
        {
            Info myInfo = new Info();
            myInfo.DisplayInfo("Midterm Program");

            new ElectionUI().MainMethod();
        }
    }
}
