﻿/*************************
 * Christopher Otto
 * MidTerm
 * Info Class, Displays student information
 * Spring 2014, ITDEV-115
 **************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MidTerm
{
    class Info
    {
        public void DisplayInfo(string assignName)
        {
            Console.WriteLine("******************************************************");
            Console.WriteLine("Name      : Chris Otto ");
            Console.WriteLine("Assignment: " + assignName);
            Console.WriteLine("Instructor: Judy Ligocki");
            Console.WriteLine("Date      : " + DateTime.Now.ToShortDateString());
            Console.WriteLine("******************************************************");
        }
    }
}
