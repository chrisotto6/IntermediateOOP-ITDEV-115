﻿/*************************
 * Christopher Otto
 * Tic Tac Toe
 * Player Class, handles all the player code
 * Spring 2014, ITDEV-115
 **************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TicTacToe
{
    public abstract class Player
    {
        const int NUM_PIECES = 2;
        char[] PIECES = { 'X', 'O' };
        static int current = 0;
        public char m_Piece;

        public Player() // Defines the player
        {
            m_Piece = PIECES[current];
            current = (current + 1) % NUM_PIECES; //toggles between the players, X and O
        }

        public char Piece //getter for piece
        {
            get { return m_Piece; }
        }

        public abstract void MakeMove(ref Board aBoard, int move);
    }

    public class ComputerPlayer : Player
    {
        
        override public void MakeMove(ref Board aBoard, int move)  //makes the move of the user
        {
            bool found = false;
            int index = 0;
            int[] BESTMOVES = { 4, 0, 2, 6, 8, 1, 3, 5, 7 };

            while (found == false && index < aBoard.NumofSquares)
            {
                move = BESTMOVES[index];

                if (aBoard.IsLegalMove(move) == true)
                    found = true;

                if (found == false)
                    index++;

            }
        }

        public void GetOpponentPiece()
        {
            
        }
    }

    public class HumanPlayer : Player
    {

        override public void MakeMove(ref Board aBoard, int move)  //makes the move of the user
        {
            aBoard.ReceiveMove(m_Piece, move);
        }
    }
}
