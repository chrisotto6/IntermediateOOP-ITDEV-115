﻿/*************************
 * Christopher Otto
 * Tic Tac Toe
 * Program class, calls new info and new game
 * Spring 2014, ITDEV-115
 **************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TicTacToe
{
    class Program
    {
        static void Main(string[] args)
        {
            Info myInfo = new Info();
            myInfo.DisplayInfo("Tic Tac Toe Game");

            GameUI ttt = new GameUI();

            ttt.PlayAgain();
            Console.ReadLine();
        }
    }
}
