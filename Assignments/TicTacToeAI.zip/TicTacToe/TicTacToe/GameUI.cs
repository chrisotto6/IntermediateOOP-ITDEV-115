﻿/*************************
 * Christopher Otto
 * Tic Tac Toe
 * GameUI, handles all the UI and front end logic for the game
 * Spring 2014, ITDEV-115
 **************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TicTacToe
{
    class GameUI
    {
        int current = 0;
        const int NUM_PLAYERS = 2;
        const int FIRST = 0;
        const int SECOND = 1;
        Player[] players = new Player[NUM_PLAYERS]; //array of players
        Board theBoard = new Board();


        public void Play()  //the controlling method
        {
            DisplayWelcome();
            players[0] = new HumanPlayer();

            Console.WriteLine("");
            
            Console.WriteLine("First piece " + players[0].Piece);

            players[1] = new ComputerPlayer();
            Console.WriteLine("Second piece " + players[1].Piece);
            int move;

            while (IsPlaying() == true)   //play until board full
            {
                DisplayGrid();

                move = PromptforMove(players[current].Piece);
                while (theBoard.IsLegalMove(move) == false)
                {
                    Console.WriteLine("Not valid move");
                    move = PromptforMove(players[current].Piece);
                }

                players[current].MakeMove(ref theBoard, move);


                NextPlayer();

            };

            DisplayGrid();
            AnnounceWinner();

        }
        public void PlayAgain() //Play again calls play once, so the user plays at least once and then keeps looping through the game as long as the user says yes
        {
            String response;
            do
            {
                Play(); //Lets the game finish, runs through the game once

                Console.WriteLine("Do you want to play again? (Y/N)");
                response = Console.ReadLine();
                if (response.Length > 0) //Takes the response if it is great than 0 then converts it to an upper
                    response = response.Substring(0, 1).ToUpper();
                theBoard.Reset();
            } while (response == "Y");//Then the upper is compared to Y if the it is Y then the user will Play again
        }
        void DisplayWelcome() //Welcomes the user to the game
        {
            Console.WriteLine("Welcome to the ultimate intellectual showdown: Tic-Tac-Toe!");
            Console.WriteLine("Make your move by entering a number 0-8, the number corresponds to a position on the board.");
        }
        bool IsPlaying() //Determines if they're still playing if the board isn't full and someone hasn't won
        {
            return (!theBoard.IsFull() && !theBoard.IsWinner(players[FIRST].Piece) && !theBoard.IsWinner(players[SECOND].Piece));
        }
        bool IsTie() //checks if the board is full and no one won
        {
            return (theBoard.IsFull() && !theBoard.IsWinner(players[FIRST].Piece) && !theBoard.IsWinner(players[SECOND].Piece));
        }
        void NextPlayer() //moves the game on the next player
        {
            if (current == 0)
                current = 1;
            else
                current = 0;
        }
        void DisplayGrid() //shows game grid
        {
            int numofelements;
            numofelements = theBoard.NumofSquares;

            char[] thegrid = new char[numofelements];
            thegrid = theBoard.TheGrid;
            Console.WriteLine("");
            Console.WriteLine(" 0 | 1 | 2\t{0} | {1} | {2} ", thegrid[0], thegrid[1], thegrid[2]);
            Console.WriteLine(" ---------\t---------");
            Console.WriteLine(" 3 | 4 | 5\t{0} | {1} | {2} ", thegrid[3], thegrid[4], thegrid[5]);
            Console.WriteLine(" ---------\t---------");
            Console.WriteLine(" 6 | 7 | 8\t{0} | {1} | {2} ", thegrid[6], thegrid[7], thegrid[8]);
        }
        public int PromptforMove(char piece) //asks user to make a move
        {
            int move;

            Console.WriteLine("Make a Move player {0} ", piece);
            int.TryParse(Console.ReadLine(), out move);

            return move;
        }
        void AnnounceWinner()//announces winner based on if there is a tie or not and who won.
        {
            Console.WriteLine("The raging battle has come to a final end.");

            if (IsTie() == true)
            {
                Console.WriteLine("Sadly, no player emerged victorious.");
            }
            else
            {
                Console.Write("The winner of this climatic confrontation is Player ");

                if (theBoard.IsWinner(players[FIRST].Piece))
                {
                    Console.WriteLine(players[FIRST].Piece + "!");
                }

                else
                {
                    Console.WriteLine(players[SECOND].Piece + "!");
                }
            }
        }
    }
}
