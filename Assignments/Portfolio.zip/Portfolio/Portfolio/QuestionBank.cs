﻿

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Portfolio
{
    class QuestionBank
    {
         private const int NUM_ANSWERS = 4;

        private const int NUM_QUESTIONS = 5;

        private QuestionUnits[] m_Questions = new QuestionUnits[5];

        public int GetNumberofAnswers
        {
            get
            {
                return 4;
            }
        }

        public int GetNumberofQuestions
        {
            get
            {
                return 5;
            }
        }


        public string GETAnswer(int index)
        {
            return this.m_Questions[index].Answer;
        }

        public string GETCorrectAnswer(int index)
        {
            return this.m_Questions[index].CorrectAnswer;
        }

        public string GETExplanation(int index)
        {
            return this.m_Questions[index].Explanation;
        }

        public string GETQuestion(int index)
        {
            return this.m_Questions[index].Question;
        }

        public void ReadQuestionFile(string path)
        {
            int num = 0;
            try
            {
                StreamReader streamReader = new StreamReader("Questions.txt");
                try
                {
                    while (true)
                    {
                        string str = streamReader.ReadLine();
                        string str1 = str;
                        if (str == null)
                        {
                            break;
                        }
                        this.m_Questions[num] = new QuestionUnits();
                        this.m_Questions[num].Question = str;
                        this.m_Questions[num].Answer = streamReader.ReadLine();
                        this.m_Questions[num].CorrectAnswer = streamReader.ReadLine();
                        this.m_Questions[num].Explanation = streamReader.ReadLine();
                        num++;
                    }
                }
                finally
                {
                    if (streamReader != null)
                    {
                        ((IDisposable)streamReader).Dispose();
                    }
                }
            }
            catch
            {
                Console.WriteLine("Exception caught and handled");
            }
        }
    }
}
