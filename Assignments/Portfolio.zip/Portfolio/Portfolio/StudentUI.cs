﻿/********************
 * Christopher Otto
 * Student Hours - Assignment 2A
 * UI Class, handled all console writing/reading and business logic
 * Spring 2014, ITDEV-115
 * *****************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Portfolio
{
    class StudentUI
    {
        string[] days = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" }; //Days of the week for the student to enter hours per the day in
        Student myStudent; //object variable

        public void MainMethod() //takes in information from the student like name and id
        {
            string id;
            string name;

            Console.WriteLine("Enter your name: ");
            name = Console.ReadLine();
            Console.WriteLine("Enter your ID: ");
            id = Console.ReadLine();

            myStudent = new Student(name, id);

            FillHours();

            DisplayData();

        }

        public void FillHours()
        {
                for (int i = 0; i < days.Length; i++)
                {
                    float hours = 0;
                    bool result = false;

                    Console.WriteLine("Enter study hours for " + days[i]);

                    while (result == false)
                    {

                        result = float.TryParse(Console.ReadLine(), out hours);

                        if (result == false)
                        {
                            Console.WriteLine("You need to type a number. Please re-enter information for " + days[i]);
                        }
                    }

                    myStudent.SetHours(i, hours);
                }
        }

        void DisplayAverage() //Displays the average hours studied by the student
        {
            Console.WriteLine("The average time studied for the student was: " + myStudent.GetAverageNumbers());
        }

        void DisplayData() //Displays all the data entered by the student to include, schedule of hours studied, total hours and average hours
        {
            Console.WriteLine("");
            Console.WriteLine("Student " + myStudent.Name + " (" + myStudent.Id + ") " + "studied the follwing time amounts.");
            Console.WriteLine("******************************************************************");
            Console.WriteLine("");

            for (int i = 0; i < days.Length; i++)
            {
                Console.WriteLine("On " + days[i] + " the student studied for " + myStudent.GetHours(i) + " hours ");
            }

            Console.WriteLine("");
            Console.WriteLine("The student studied for a total of: " + myStudent.GetNumberHours());;
            DisplayAverage();

            Console.ReadLine();//Stops the application so that data can be verified
        }
    }
}
