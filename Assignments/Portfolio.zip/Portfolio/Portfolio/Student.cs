﻿/********************
 * Christopher Otto
 * Student Hours - Assignment 2A
 * Logic class, handles methods, getters and setters. Back end computation.
 * Spring 2014, ITDEV-115
 * *****************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Portfolio
{
    class Student
    {
        float[] hours = new float[7];
        string name;
        string id;

        //Properties
        public string Id
        {
            //set through the constructor..
            get { return id; } //Getter of the id
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        //Methods
        public Student(string name, string theID)
        {
            id = theID;
            this.name = name;
            for (int i = 0; i < hours.Length; i++)
            {
                hours[i] = 0;
            }
        }

        //Method getter setter denoted by the use ()
        public void SetHours(int index, float value)
        {
            hours[index] = value;
        }

        public float GetHours(int index)
        {
            return hours[index];
        }

        public float GetAverageNumbers() //Calculates the average by looping through the array and totaling the total and then dividing by 7 the number of days
        {
            float totalHours = 0;
            float averageHours;

            for (int i = 0; i < hours.Length; i++)
            {
                totalHours = totalHours + hours[i];
            }

            averageHours = totalHours / 7;
            return averageHours;
        }

        public float GetNumberHours() //Gets the total number of hours enter into the hours array by the user and will get printed in the DisplayData portion in the UI
        {
            float totalHours = 0;

            for (int i = 0; i < hours.Length; i++)
            {
                totalHours = totalHours + hours[i];
            }

            return totalHours;
        }
    }
}
