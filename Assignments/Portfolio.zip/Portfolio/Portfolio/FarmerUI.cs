﻿/*************************
 * Christopher Otto
 * Farmer Game
 * FarmerUI Class, Handles the UI concerns for the Farmer Game
 * Spring 2014, ITDEV-115
 **************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Portfolio
{
    class FarmerUI
    {
        //
        FarmerLogic thegame; 
        void Play()
        {
            DisplayWelcome();

            thegame = new FarmerLogic(); //new game.

            do
            {
                DisplayHint(); 

                DisplayGameState();

                ProcessChoice();

                Console.Clear();
                
            } while (thegame.GameOver() == false);
        }

        public void PlayAgain()
        {

            string playAgain;
            do
            {
                Play();

                Console.WriteLine("Would you like to play the Farmer Game again? Please enter Yes or No.");
                playAgain = Console.ReadLine();
            } while (playAgain.Substring(0, 1).ToUpper() == "Y");
        }

        void DisplayWelcome() //Displays Welcome/Backstory of the game
        {
            Console.WriteLine("+++++++++++++++++++++++WELCOME TO THE FARMER GAME++++++++++++++++++++++++++");
            Console.Write("A farmer must get his fox, chicken and grain safely across a river from North bank to South bank.");
            Console.Write("The farmer makes trips between the banks and can take at most ONE item with him each time.");
            Console.Write("Unfortunately, if the farmer leaves the chicken and grain together, the chicken eats the grain.");
            Console.Write("Also, if the farmer leaves the fox and chicken together, the fox eats the chicken.");
            Console.Write("The player must help the farmer by deciding what he should take across the river on each trip.");
            Console.Write("Once the player helps the farmer move all three items successfully to the south bank, he wins.");
            Console.Write("However, if the chicken or grain gets eaten, the player loses.");
            Console.WriteLine("\n+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        }

        void DisplayHint() //Continues to show the user what to enter as the application runs
        {
            Console.WriteLine("\nEnter chicken, grain, fox or return to move the items. Return has the farmer go across empty handed.");
        }

        string PromptForMove()
        {
            string choice;
            Console.WriteLine("\nEnter your Choice: ");
            choice = Console.ReadLine();
            return choice;
        }

        void ProcessChoice()
        {
            string choice = "";

            choice = PromptForMove();

            if (choice.Length > 0)
            {
                if (choice.Substring(0, 1).ToUpper() == "C")
                    choice = "CHICKEN";
                else if (choice.Substring(0, 1).ToUpper() == "G")
                    choice = "GRAIN";
                else if (choice.Substring(0, 1).ToUpper() == "F")
                    choice = "FOX";
                else
                    choice = "NOTHING";

                thegame.Move(choice);
            }
        }

        void DisplayGameState()
        {
            Console.WriteLine("\nFarmer is at the " + thegame.Farmer + " bank");
            DisplayNorthBank();
            DisplayRiver();
            DisplaySouthBank();
        }

        void DisplayRiver()
        {
            Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        }

        void DisplaySouthBank()
        {
            string southbank;
            southbank = thegame.SouthBank;
            Console.Write(southbank);
        }

        void DisplayNorthBank()
        {
            List<string> north;
            north = thegame.NorthBank;

            //int index = 1;
            foreach (string value in north)
            {

                Console.Write(value + "   ");
                // index++;
            }
            Console.WriteLine();

        }
    }
}
