﻿/*************************
 * Christopher Otto
 * Tic Tac Toe
 * Board class, handles the board operations
 * Spring 2014, ITDEV-115
 **************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Portfolio
{
    public class Board
    {
        const int NUM_SQUARES = 9;
        char[] m_Squares = new char[NUM_SQUARES];
        const char EMPTY = ' ';

        public Board()
        {
            Reset();
        }
        public int NumofSquares
        {
            get { return NUM_SQUARES; }
        }
        public char[] TheGrid  //returns the actual board
        {
            get { return m_Squares; }
        }
        public void Reset() //resets the board after the game has been completed
        {
            for (int i = 0; i < NUM_SQUARES; i++)
            {
                m_Squares[i] = EMPTY;
            }

        }
        public void ReceiveMove(char piece, int move) //takes the move of the user
        {
            m_Squares[move] = piece;
        }
        public bool IsFull() //determines if board is full
        {
            bool full = true;
            int i = 0;

            while (full && i < NUM_SQUARES)
            {
                if (m_Squares[i] == EMPTY)
                {
                    full = false;
                }
                i++;

            }
            return full;
        }
        public bool IsLegalMove(int move)//determines if the move is legal, in range and there is not a value there already
        {
            bool result;

            if (move >= 0 && move < NUM_SQUARES && m_Squares[move] == EMPTY)
                result = true;
            else
                result = false;

            return result;

        }
        public bool IsWinner(char piece) //Determines winner of the game
        {
            bool winner = false;
            //check 3 ways across
            if (m_Squares[0] == piece && m_Squares[1] == piece && m_Squares[2] == piece)
                winner = true;
            if (m_Squares[3] == piece && m_Squares[4] == piece && m_Squares[5] == piece)
                winner = true;
            if (m_Squares[6] == piece && m_Squares[7] == piece && m_Squares[8] == piece)
                winner = true;
            //check 3 ways down
            if (m_Squares[0] == piece && m_Squares[3] == piece && m_Squares[6] == piece)
                winner = true;
            if (m_Squares[1] == piece && m_Squares[4] == piece && m_Squares[7] == piece)
                winner = true;
            if (m_Squares[2] == piece && m_Squares[5] == piece && m_Squares[8] == piece)
                winner = true;
            //Check 2 ways diagonal
            if (m_Squares[0] == piece && m_Squares[4] == piece && m_Squares[8] == piece)
                winner = true;
            if (m_Squares[2] == piece && m_Squares[4] == piece && m_Squares[6] == piece)
                winner = true;

            return winner;
        }
    }
}
