﻿/*************************
 * Christopher Otto
 * Jumble Game
 * UI Class
 * Spring 2014, ITDEV-115
 **************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Portfolio
{
    class UIJumble
    {
        public void Play() //controlling method - The Actual Game
        {
            JumbleLogic thegame = new JumbleLogic(); //constructor

            DisplayWelcome(); //Displays the welcome of the game defined by the DisplayWelcome function below

            //Console.WriteLine("Hidden Word " + thegame.HiddenWord);   Used for testing the pulling of the Hidden word

            Console.WriteLine("Here is your word to guess: " + thegame.DisplayWord()); //Displays jumbled word for the user to guess

            bool correctGuess;

            do
            {
                string guess;

                guess = TakeAGuess(); //uses the guess string to assign the users guess from TakeAGuess
                correctGuess = thegame.CompareString(guess); //Uses the boolean correctGuess to see if the users guess is correct via the compare string function

                if (correctGuess == true) //if the guess is right then print out the congrats message
                {
                    Console.WriteLine(""); 
                    Console.WriteLine("");
                    Console.WriteLine("You are correct! You have won and beaten this extremely hard game!"); //Displays the congratulations message to the user
                }
                else //if the guess is wrong then inform the user and then display their guess to them again
                {
                    Console.WriteLine("");
                    Console.WriteLine("");
                    Console.WriteLine("Your guess was wrong please try again! You have brought shame to your family!");
                    Console.WriteLine("Since you didn't get it the first time here is your word : " + thegame.DisplayWord());
                }

            } while (correctGuess == false); //Keep looping through the process until the user has a correct guess 

        }

        public void DisplayWelcome() //Prints the introduction of the game to the user
        {
            Console.WriteLine("");
            Console.WriteLine("**********************************************");
            Console.WriteLine("**                                          **");
            Console.WriteLine("**       WELCOME TO THE JUMBLE GAME         **");
            Console.WriteLine("**         GUESS THE CORRECT WORD           **");
            Console.WriteLine("**              AND WIN!!!!!!               **");
            Console.WriteLine("**                                          **");
            Console.WriteLine("**********************************************");
            Console.WriteLine("");
        }

        public string TakeAGuess() //Prompts the user to take a guess and returns it for compare later.
        {
            Console.WriteLine("");
            Console.WriteLine("Please Enter a Guess for the word: ");
            Console.WriteLine("");
            string guess = null;
            
            guess = Console.ReadLine(); //assigns the users guess to the guess string

            return guess;
        }

        public void PlayAgain() //Play again calls play once, so the user plays at least once and then keeps looping through the game as long as the user says yes
        {
            String response;
            do
            {
                Play(); //Lets the game finish, runs through the game once

                Console.WriteLine("Do you want to play again? (Y/N)");
                response = Console.ReadLine();
                if (response.Length > 0) //Takes the response if it is great than 0 then converts it to an upper
                    response = response.Substring(0, 1).ToUpper();

            } while (response == "Y"); //Then the upper is compared to Y if the it is Y then the user will Play again
        }
        //PromptforGuess


    }
}
