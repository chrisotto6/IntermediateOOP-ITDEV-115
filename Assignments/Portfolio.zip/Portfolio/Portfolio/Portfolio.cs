﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Portfolio
{
    class Portfolio
    {
        public void DisplayWelcome()
        {
            Console.WriteLine("***********************************************");
            Console.WriteLine("*        Weclome to my final Portfolio        *");
            Console.WriteLine("*   Please enter a number for an application  *");
            Console.WriteLine("*      Enter 7 to exit the application        *");
            Console.WriteLine("***********************************************");
        }

        public void DisplayMenu()
        {
            Console.WriteLine();
            Console.WriteLine("1) Baseball Player");
            Console.WriteLine("2) Jumble Game");
            Console.WriteLine("3) Student Hours");
            Console.WriteLine("4) Farmer Game");
            Console.WriteLine("5) Tic Tac Toe");
            Console.WriteLine("6) Trivia Game");
            Console.WriteLine("7) Exit");
        }

        public void PortfolioMain()
        {
            int num = 0;
            this.DisplayWelcome();
            while (num != 7)
            {
                this.DisplayMenu();
                Console.WriteLine();
                Console.Write("Please enter your choice: ");

                try
                {
                    num = Convert.ToInt16(Console.ReadLine());
                }
                catch
                {
                    Console.WriteLine("         ERROR         ");
                    Console.WriteLine("You must enter a Number");
                    Console.WriteLine();
                    continue;
                }
                this.ProcessMenu(num);
            }
        }


        public void ProcessMenu(int response)
        {
            switch (response)
            {
                case 1:
                    {
                        //Creating the first baseball player as a new BaseBallPlayer and assigning the values to it
                        BaseBallPlayer firstBallPlayer = new BaseBallPlayer();
                        firstBallPlayer.BattingAvg = ".303";
                        firstBallPlayer.FirstName = "Ryan";
                        firstBallPlayer.LastName = "Braun";
                        firstBallPlayer.Team = "Milwaukee Brewers";

                        //Creating the second baseball player as a new BaseBallPlayer and assigning the values to it
                        BaseBallPlayer secondBallPlayer = new BaseBallPlayer();
                        secondBallPlayer.BattingAvg = ".400";
                        secondBallPlayer.FirstName = "Chris";
                        secondBallPlayer.LastName = "Otto";
                        secondBallPlayer.Team = "Milwaukee Brewers";

                        //Calling DisplayInfo on each new BaseBallPlayer to print out the information
                        firstBallPlayer.DisplayInfo();
                        secondBallPlayer.DisplayInfo();

                        //Added so that the application stops to validate the data that was entered and printed
                        Console.ReadLine();

                        break;
                    }
                case 2:
                    {
                        UIJumble theUI = new UIJumble();
                        theUI.PlayAgain(); //Plays the game PlayAgain calls Play so that the user plays the game at least once

                        break;
                    }
                case 3:
                    {
                        StudentUI theUI = new StudentUI();
                        theUI.MainMethod();

                        break;
                    }
                case 4:
                    {
                        FarmerUI theUI = new FarmerUI();
                        theUI.PlayAgain();

                        break;
                    }
                case 5:
                    {
                        GameUI ttt = new GameUI();
                        ttt.PlayAgain();

                        break;
                    }
                case 6:
                    {
                        (new TriviaUI()).PlayAgain();

                        break;
                    }
                case 7:
                    {
                        break;
                    }
                default:
                    {
                        Console.WriteLine("Invalid entry");
                        break;
                    }
                }
            }
        }
    }

