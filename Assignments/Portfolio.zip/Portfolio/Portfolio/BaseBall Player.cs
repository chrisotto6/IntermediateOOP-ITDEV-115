﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Portfolio
{
    class BaseBallPlayer
    {
        //Define the variables that will be used for the baseball players, just initialization
        String battingAvg;
        String firstName;
        String lastName;
        String team;

        //Set the initialized variables set to NULL values for assignment later in the program, Default Constructor = No return type
        public BaseBallPlayer()
        {
            battingAvg = "";
            firstName = "";
            lastName = "";
            team = "";
        }
        
        //Assigning Get and Set permission with properties for battingAvg, firstName, lastName and team
        public string BattingAvg
        {
            get { return battingAvg; }
            set { battingAvg = value; }
        }

        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }

        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }

        public string Team
        {
            get { return team; }
            set { team = value; }
        }

        //DisplayInfo will display the information for the variables for each baseball player entered in main of the application
        public void DisplayInfo()
        {
            Console.WriteLine("Batting Average : " + battingAvg);
            Console.WriteLine("First Name : " + firstName);
            Console.WriteLine("Last Name : " + lastName);
            Console.WriteLine("Team : " + team);
            //Adding extra blank line in printing to make baseball players printed to not be clustered
            Console.WriteLine("");
        }
    }
}
