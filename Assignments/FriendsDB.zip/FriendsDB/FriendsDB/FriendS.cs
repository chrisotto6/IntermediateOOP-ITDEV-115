﻿    using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data; //needed for dataset
using System.Data.OleDb; //need for OLEDB controls.

namespace FriendsDB
{
    class FriendS
    {
        public string OpenDatabase(ref DataSet friendDS)
        {
            string errorstring = null;

            try
            {

                string sConnection = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=member.accdb";
                string sql = "SELECT * FROM memberTable ORDER BY LastName ASC";
                OleDbCommand dbCmd = new OleDbCommand();
                OleDbDataAdapter dbAdapter;


                OleDbConnection dbConn = new OleDbConnection(sConnection);
                dbConn.Open();

                dbCmd.CommandText = sql;
                dbCmd.Connection = dbConn;

                dbAdapter = new OleDbDataAdapter();
                dbAdapter.SelectCommand = dbCmd;

                //fill dataSet..
                dbAdapter.Fill(friendDS, "memberTable");

                return errorstring;
            }
            catch (Exception ex)
            {
                errorstring = ex.Message;
                return errorstring;
            }



        }
        public DataSet SearchFriends(string search, ref int records, ref string error)
        {
            string sconn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=member.accdb";
            string sSql = "Select * from memberTable where LastName like '" + search + "%'";

            OleDbConnection dbConn; //object variable;
            OleDbDataAdapter daFriends;

            DataSet dsFriends = new DataSet();  //empty Data Set.

            try
            {
                dbConn = new OleDbConnection(sconn);
                dbConn.Open();
                daFriends = new OleDbDataAdapter(sSql, dbConn);  //sql as string, connection'

                records = daFriends.Fill(dsFriends);
            }

            catch (Exception ex)
            {
                error = "Error " + ex.Message;

            }

            return dsFriends;

        }
    }
}
