﻿/*************************
 * Christopher Otto
 * Friend Forms
 * Spring 2014, ITDEV-115
 **************************/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace FriendsDB
{
    public partial class FriendForm : Form
    {

        FriendS myFriends;
        DataSet friendDS = new DataSet();

        public FriendForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            myFriends = new FriendS();
            string error;

            error = myFriends.OpenDatabase(ref friendDS);

            if (error != null)
            {
                MessageBox.Show(error);
                Close();
            }
            else
            {
                cboLast.DataSource = friendDS.Tables[0];
                cboLast.DisplayMember = "LastName";
            }
        }

        private void cboLast_SelectedIndexChanged(object sender, EventArgs e)
        {
            int count = 0;

            if (cboLast.SelectedIndex > -1)
            {
                count = cboLast.SelectedIndex;
                txtFirst.Text = friendDS.Tables[0].Rows[count].ItemArray[2].ToString();
                txtPhone.Text = friendDS.Tables[0].Rows[count].ItemArray[3].ToString();
                txtAddress.Text = friendDS.Tables[0].Rows[count].ItemArray[4].ToString();
                txtCity.Text = friendDS.Tables[0].Rows[count].ItemArray[5].ToString();
                txtZipCode.Text = friendDS.Tables[0].Rows[count].ItemArray[6].ToString();
                txtEmail.Text = friendDS.Tables[0].Rows[count].ItemArray[7].ToString();
            }
        }
    }
}
