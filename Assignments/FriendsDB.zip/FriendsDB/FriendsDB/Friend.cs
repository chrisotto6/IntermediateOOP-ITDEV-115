﻿/*************************
 * Christopher Otto
 * Friend Class
 * Spring 2014, ITDEV-115
 **************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FriendsDB
{
    class Friend
    {
        private string id;
        private string firstName;
        private string lastName;
        private string phoneNumber;
        private string address;
        private string city;
        private string zipCode;
        private string email;

        public Friend()
        {
        }
        

        public string FirstName
        {
            get
            {
                return firstName;
            }
        }

        public string LastName
        {
            get
            {
                return lastName;
            }
        }

        public string Id
        {
            get
            {
                return id;
            }
        }

        public string PhoneNumber
        {
            get
            {
                return phoneNumber;
            }
        }

        public string Address
        {
            get
            {
                return address;
            }
        }

        public string City
        {
            get
            {
                return city;
            }
        }

        public string ZipCode
        {
            get
            {
                return zipCode;
            }
        }

        public string Email
        {
            get
            {
                return email;
            }
        }
        
    }
}
