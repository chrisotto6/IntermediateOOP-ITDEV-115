﻿namespace FarmerUI
{
    partial class FarmerGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FarmerGame));
            this.picNorthFarmer = new System.Windows.Forms.PictureBox();
            this.picSouthFarmer = new System.Windows.Forms.PictureBox();
            this.picNorthFox = new System.Windows.Forms.PictureBox();
            this.picNorthChicken = new System.Windows.Forms.PictureBox();
            this.picNorthGrain = new System.Windows.Forms.PictureBox();
            this.picSouthFox = new System.Windows.Forms.PictureBox();
            this.picSouthChicken = new System.Windows.Forms.PictureBox();
            this.picSouthGrain = new System.Windows.Forms.PictureBox();
            this.lblNorthBank = new System.Windows.Forms.Label();
            this.lblSouthBank = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.infoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.picNorthFarmer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSouthFarmer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNorthFox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNorthChicken)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNorthGrain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSouthFox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSouthChicken)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSouthGrain)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // picNorthFarmer
            // 
            this.picNorthFarmer.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.picNorthFarmer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.picNorthFarmer.Image = ((System.Drawing.Image)(resources.GetObject("picNorthFarmer.Image")));
            this.picNorthFarmer.Location = new System.Drawing.Point(77, 26);
            this.picNorthFarmer.Name = "picNorthFarmer";
            this.picNorthFarmer.Size = new System.Drawing.Size(72, 97);
            this.picNorthFarmer.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picNorthFarmer.TabIndex = 0;
            this.picNorthFarmer.TabStop = false;
            this.picNorthFarmer.Click += new System.EventHandler(this.northBank_Click);
            // 
            // picSouthFarmer
            // 
            this.picSouthFarmer.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.picSouthFarmer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.picSouthFarmer.Image = ((System.Drawing.Image)(resources.GetObject("picSouthFarmer.Image")));
            this.picSouthFarmer.Location = new System.Drawing.Point(77, 350);
            this.picSouthFarmer.Name = "picSouthFarmer";
            this.picSouthFarmer.Size = new System.Drawing.Size(72, 97);
            this.picSouthFarmer.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picSouthFarmer.TabIndex = 1;
            this.picSouthFarmer.TabStop = false;
            this.picSouthFarmer.Click += new System.EventHandler(this.picSouthFarmer_Click);
            // 
            // picNorthFox
            // 
            this.picNorthFox.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.picNorthFox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.picNorthFox.Image = ((System.Drawing.Image)(resources.GetObject("picNorthFox.Image")));
            this.picNorthFox.Location = new System.Drawing.Point(242, 26);
            this.picNorthFox.Name = "picNorthFox";
            this.picNorthFox.Size = new System.Drawing.Size(72, 97);
            this.picNorthFox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picNorthFox.TabIndex = 2;
            this.picNorthFox.TabStop = false;
            this.picNorthFox.Click += new System.EventHandler(this.picNorthFox_Click);
            // 
            // picNorthChicken
            // 
            this.picNorthChicken.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.picNorthChicken.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.picNorthChicken.Image = ((System.Drawing.Image)(resources.GetObject("picNorthChicken.Image")));
            this.picNorthChicken.Location = new System.Drawing.Point(598, 26);
            this.picNorthChicken.Name = "picNorthChicken";
            this.picNorthChicken.Size = new System.Drawing.Size(72, 97);
            this.picNorthChicken.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picNorthChicken.TabIndex = 3;
            this.picNorthChicken.TabStop = false;
            this.picNorthChicken.Click += new System.EventHandler(this.picNorthChicken_Click);
            // 
            // picNorthGrain
            // 
            this.picNorthGrain.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.picNorthGrain.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.picNorthGrain.Image = ((System.Drawing.Image)(resources.GetObject("picNorthGrain.Image")));
            this.picNorthGrain.Location = new System.Drawing.Point(763, 26);
            this.picNorthGrain.Name = "picNorthGrain";
            this.picNorthGrain.Size = new System.Drawing.Size(72, 97);
            this.picNorthGrain.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picNorthGrain.TabIndex = 4;
            this.picNorthGrain.TabStop = false;
            this.picNorthGrain.Click += new System.EventHandler(this.picNorthGrain_Click);
            // 
            // picSouthFox
            // 
            this.picSouthFox.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.picSouthFox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.picSouthFox.Image = ((System.Drawing.Image)(resources.GetObject("picSouthFox.Image")));
            this.picSouthFox.Location = new System.Drawing.Point(242, 350);
            this.picSouthFox.Name = "picSouthFox";
            this.picSouthFox.Size = new System.Drawing.Size(72, 97);
            this.picSouthFox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picSouthFox.TabIndex = 5;
            this.picSouthFox.TabStop = false;
            this.picSouthFox.Click += new System.EventHandler(this.picSouthFox_Click);
            // 
            // picSouthChicken
            // 
            this.picSouthChicken.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.picSouthChicken.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.picSouthChicken.Image = ((System.Drawing.Image)(resources.GetObject("picSouthChicken.Image")));
            this.picSouthChicken.Location = new System.Drawing.Point(598, 350);
            this.picSouthChicken.Name = "picSouthChicken";
            this.picSouthChicken.Size = new System.Drawing.Size(72, 97);
            this.picSouthChicken.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picSouthChicken.TabIndex = 6;
            this.picSouthChicken.TabStop = false;
            this.picSouthChicken.Click += new System.EventHandler(this.picSouthChicken_Click);
            // 
            // picSouthGrain
            // 
            this.picSouthGrain.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.picSouthGrain.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.picSouthGrain.Image = ((System.Drawing.Image)(resources.GetObject("picSouthGrain.Image")));
            this.picSouthGrain.Location = new System.Drawing.Point(763, 350);
            this.picSouthGrain.Name = "picSouthGrain";
            this.picSouthGrain.Size = new System.Drawing.Size(72, 97);
            this.picSouthGrain.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picSouthGrain.TabIndex = 7;
            this.picSouthGrain.TabStop = false;
            this.picSouthGrain.Click += new System.EventHandler(this.picSouthGrain_Click);
            // 
            // lblNorthBank
            // 
            this.lblNorthBank.AutoSize = true;
            this.lblNorthBank.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.lblNorthBank.Font = new System.Drawing.Font("Comic Sans MS", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNorthBank.Location = new System.Drawing.Point(368, 50);
            this.lblNorthBank.Name = "lblNorthBank";
            this.lblNorthBank.Size = new System.Drawing.Size(179, 40);
            this.lblNorthBank.TabIndex = 8;
            this.lblNorthBank.Text = "North Bank";
            // 
            // lblSouthBank
            // 
            this.lblSouthBank.AutoSize = true;
            this.lblSouthBank.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.lblSouthBank.Font = new System.Drawing.Font("Comic Sans MS", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSouthBank.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblSouthBank.Location = new System.Drawing.Point(368, 379);
            this.lblSouthBank.Name = "lblSouthBank";
            this.lblSouthBank.Size = new System.Drawing.Size(176, 40);
            this.lblSouthBank.TabIndex = 9;
            this.lblSouthBank.Text = "South Bank";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(914, 24);
            this.menuStrip1.TabIndex = 10;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.infoToolStripMenuItem,
            this.resetToolStripMenuItem,
            this.quitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // infoToolStripMenuItem
            // 
            this.infoToolStripMenuItem.Name = "infoToolStripMenuItem";
            this.infoToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.infoToolStripMenuItem.Text = "Info";
            this.infoToolStripMenuItem.Click += new System.EventHandler(this.infoToolStripMenuItem_Click);
            // 
            // resetToolStripMenuItem
            // 
            this.resetToolStripMenuItem.Name = "resetToolStripMenuItem";
            this.resetToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.resetToolStripMenuItem.Text = "Reset";
            this.resetToolStripMenuItem.Click += new System.EventHandler(this.resetToolStripMenuItem_Click);
            // 
            // quitToolStripMenuItem
            // 
            this.quitToolStripMenuItem.Name = "quitToolStripMenuItem";
            this.quitToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.quitToolStripMenuItem.Text = "Quit";
            this.quitToolStripMenuItem.Click += new System.EventHandler(this.quitToolStripMenuItem_Click);
            // 
            // FarmerGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(914, 471);
            this.Controls.Add(this.lblSouthBank);
            this.Controls.Add(this.lblNorthBank);
            this.Controls.Add(this.picSouthGrain);
            this.Controls.Add(this.picSouthChicken);
            this.Controls.Add(this.picSouthFox);
            this.Controls.Add(this.picNorthGrain);
            this.Controls.Add(this.picNorthChicken);
            this.Controls.Add(this.picNorthFox);
            this.Controls.Add(this.picSouthFarmer);
            this.Controls.Add(this.picNorthFarmer);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FarmerGame";
            this.Text = "Farmer Game";
            this.Load += new System.EventHandler(this.FarmerGame_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picNorthFarmer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSouthFarmer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNorthFox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNorthChicken)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNorthGrain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSouthFox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSouthChicken)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSouthGrain)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picNorthFarmer;
        private System.Windows.Forms.PictureBox picSouthFarmer;
        private System.Windows.Forms.PictureBox picNorthFox;
        private System.Windows.Forms.PictureBox picNorthChicken;
        private System.Windows.Forms.PictureBox picNorthGrain;
        private System.Windows.Forms.PictureBox picSouthFox;
        private System.Windows.Forms.PictureBox picSouthChicken;
        private System.Windows.Forms.PictureBox picSouthGrain;
        private System.Windows.Forms.Label lblNorthBank;
        private System.Windows.Forms.Label lblSouthBank;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem infoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resetToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quitToolStripMenuItem;
    }
}

