﻿/*************************
 * Christopher Otto
 * Farmer Game
 * Logic Class, handles the backend operations of the game
 * Spring 2014, ITDEV-115
 **************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FarmerUI
{
    class FarmerLogic
    {
        public enum Direction { north, south }; //creation of the enumerator 

        List<string> northbank; //object variable.
        List<string> southbank;
        Direction farmer;

        public FarmerLogic() //sets the state of the game and adds the items to the northbank
        {
            northbank = new List<string>();
            southbank = new List<string>();
            farmer = Direction.north;

            northbank.Add("CHICKEN");
            northbank.Add("FOX");
            northbank.Add("GRAIN");
            

        }
        public Direction Farmer //Getter of the direction of the farmer
        {
            get { return farmer; }
        }

        public List<string> NorthBank //Gets the items in the northbank
        {
            get { return northbank; }
        }

        public List<string> SouthBank //Gets the items in the northbank
        {
            get { return southbank; }
        }

        public bool GameOver() //Determines if the player won or lost
        {
            bool over = false;

            if (AnimalAteFood() == true) //If the AnimalAteFood is true then the player lost and through the playAgain loop will be asked to try again
            {
                Console.WriteLine("Oops you forgot that the Chicken can't be left with either the Grain or the Fox!");
                Console.WriteLine("\n**********************GAME OVER************************");
                Console.WriteLine("");
                over = true;
            }
            else if (DetermineWin() == true) //If Determine win is true then the user will get the victory prompt and loop will ask to play again
            { 
                Console.WriteLine("Congratulations you have safely made it across the river! You did not allow for");
                Console.WriteLine("any of the animals or grain to get eaten along the way. You should give");
                Console.WriteLine("yourself a big pat on the back for a job well done. ");
                Console.WriteLine("");
                over = true;
            }

            return over;
        }

        public void Move(string choice) //Process the move of the item by the player
        {
            bool success = false;

            if (farmer == Direction.north) //moving south because the Farmer is at the North
            {
              
                success = northbank.Remove(choice);
                
                if (success == true)
                    southbank.Add(choice);

                farmer = Direction.south;
            }
            else //Farmer at South Bank, because he's not a the North Bank
            {
                success = southbank.Remove(choice);

                if (success == true)
                    northbank.Add(choice);

                farmer = Direction.north;
            }
        }
        public bool AnimalAteFood() //Determines if the chicken/grain or chicken/fox were left alone at either bank and will result in the loss of the game
        {
            bool animalAteFood = false;

            if (farmer == Direction.north)
            {
                if (southbank.Contains("CHICKEN") && southbank.Contains("FOX") && northbank.Contains("GRAIN"))
                {
                    animalAteFood = true;
                }
                else if (southbank.Contains("CHICKEN") && southbank.Contains("GRAIN") && northbank.Contains("FOX"))
                {
                    animalAteFood = true;
                }
            }

            if (farmer == Direction.south)
            {
                if (northbank.Contains("CHICKEN") && northbank.Contains("FOX") && southbank.Contains("GRAIN"))
                {
                    animalAteFood = true;
                }
                else if (northbank.Contains("CHICKEN") && northbank.Contains("GRAIN") && southbank.Contains("FOX"))
                {
                    animalAteFood = true;
                }
            }

            return animalAteFood;
        }

        public bool DetermineWin() //If all the items and the farmer are at the southbank then the user wins
        {
            bool win = false;
            if (farmer == Direction.south)
            {
                if (southbank.Contains("CHICKEN") && southbank.Contains("GRAIN") && southbank.Contains("FOX"))
                {
                    win = true;
                }
            }
            return win;            
        }
    }
}
