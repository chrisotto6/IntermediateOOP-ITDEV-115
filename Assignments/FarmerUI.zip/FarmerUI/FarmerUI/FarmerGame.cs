﻿/*************************
 * Christopher Otto
 * Farmer Game GUI
 * Handles all the UI for the GUI of the Farmer Game
 * Spring 2014, ITDEV-115
 **************************/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FarmerUI
{
    public partial class FarmerGame : Form
    {
        FarmerLogic mygame;

        public FarmerGame()
        {
            InitializeComponent();
        }

        private void FarmerGame_Load(object sender, EventArgs e)
        {
            mygame = new FarmerLogic();

            DisableAll();
            DisplayNorthBank();
            DisplaySouthBank();
        }

        void DisableAll()
        {
            picNorthFarmer.Visible = false;
            picNorthChicken.Visible = false;
            picNorthFox.Visible = false;
            picNorthGrain.Visible = false;

            picSouthFarmer.Visible = false;
            picSouthChicken.Visible = false;
            picSouthFox.Visible = false;
            picSouthGrain.Visible = false;

            picNorthFarmer.Enabled = false;
            picNorthChicken.Enabled = false;
            picNorthFox.Enabled = false;
            picNorthGrain.Enabled = false;

            picSouthFarmer.Enabled = false;
            picSouthChicken.Enabled = false;
            picSouthFox.Enabled = false;
            picSouthGrain.Enabled = false;
        }

        //Display the Northbank
        void DisplayNorthBank()
        {
            List<string> northbank;
            northbank = mygame.NorthBank;

            if (this.mygame.Farmer == FarmerLogic.Direction.north)
            {
                picNorthFarmer.Visible = true;
                picNorthFarmer.Enabled = true;
                picNorthChicken.Enabled = true;
                picNorthFox.Enabled = true;
                picNorthGrain.Enabled = true;

            }
            if (northbank.Contains("CHICKEN"))
            {
                picNorthChicken.Visible = true;
            }
            if (northbank.Contains("FOX"))
            {
                picNorthFox.Visible = true;
            }
            if (northbank.Contains("GRAIN"))
            {
                picNorthGrain.Visible = true;
            }
        }


        //Display SouthBank
        void DisplaySouthBank()
        {
            List<string> southbank;
            southbank = mygame.SouthBank;
            if (mygame.Farmer == FarmerLogic.Direction.south)
            {
                picSouthFarmer.Visible = true;
                picSouthFarmer.Enabled = true;
                picSouthChicken.Enabled = true;
                picSouthFox.Enabled = true;
                picSouthGrain.Enabled = true;
            }
            if (southbank.Contains("CHICKEN"))
            {
                picSouthChicken.Visible = true;
            }
            if (southbank.Contains("FOX"))
            {
                picSouthFox.Visible = true;
            }
            if (southbank.Contains("GRAIN"))
            {
                picSouthGrain.Visible = true;
            }
        }
        private void northBank_Click(object sender, EventArgs e)
        {
            mygame.Move("nothing");
            DisableAll();
            DisplayNorthBank();
            DisplaySouthBank();
            EndofGame();
        }

        private void picNorthFox_Click(object sender, EventArgs e)
        {
            mygame.Move("FOX");
            DisableAll();
            DisplayNorthBank();
            DisplaySouthBank();
            EndofGame();
        }

        private void picSouthFox_Click(object sender, EventArgs e)
        {
            mygame.Move("FOX");
            DisableAll();
            DisplayNorthBank();
            DisplaySouthBank();
            EndofGame();
        }

        private void picNorthChicken_Click(object sender, EventArgs e)
        {
            mygame.Move("CHICKEN");
            DisableAll();
            DisplayNorthBank();
            DisplaySouthBank();
            EndofGame();
        }

        private void picSouthChicken_Click(object sender, EventArgs e)
        {
            mygame.Move("CHICKEN");
            DisableAll();
            DisplayNorthBank();
            DisplaySouthBank();
            EndofGame();
        }

        private void picNorthGrain_Click(object sender, EventArgs e)
        {
            mygame.Move("GRAIN");
            DisableAll();
            DisplayNorthBank();
            DisplaySouthBank();
            EndofGame();
        }

        private void picSouthGrain_Click(object sender, EventArgs e)
        {
            mygame.Move("GRAIN");
            DisableAll();
            DisplayNorthBank();
            DisplaySouthBank();
            EndofGame();
        }

        private void picSouthFarmer_Click(object sender, EventArgs e)
        {
            mygame.Move("nothing");
            DisableAll();
            DisplayNorthBank();
            DisplaySouthBank();
            EndofGame();
        }

        private void EndofGame()
        {
            if (mygame.GameOver() == true)
            {
                if (mygame.AnimalAteFood() == true)
                {
                    MessageBox.Show("You lose!! Animal ate the food");
                    DisableAll();
                }
                if (mygame.DetermineWin() == true)
                {
                    MessageBox.Show("You win the game, congratulations!");
                    DisableAll();
                }
            }            
        }

        private void infoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("ITDEV-115 Spring 2014\nWritten By: Christopher Otto", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void resetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mygame = new FarmerLogic();  //creates new game
            DisableAll();
            DisplayNorthBank();
            DisplaySouthBank();
        }

        private void quitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
