﻿/*************************
 * Christopher Otto
 * Jumble Game
 * Spring 2014, ITDEV-115
 **************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2JumbleGame
{
    class MainModule
    {
        static void Main(string[] args)
        {
            Info myInfo = new Info();
            myInfo.DisplayInfo("Assignment 2 - Jumble Game");

            UIJumble theUI = new UIJumble();
            theUI.PlayAgain(); //Plays the game PlayAgain calls Play so that the user plays the game at least once

            Console.ReadLine();

        }
    }
}
