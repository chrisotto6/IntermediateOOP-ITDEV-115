﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2JumbleGame
{
    class Info
    {
        public void DisplayInfo(string assignName)
        {
            Console.WriteLine("******************************************************");
            Console.WriteLine("Name      : Chris Otto ");
            Console.WriteLine("Assignment: " + assignName);
            Console.WriteLine("Instructor: Judy Ligocki");
            Console.WriteLine("Date      : " + DateTime.Now.ToShortDateString());
            Console.WriteLine("******************************************************");
        }
    }
}
