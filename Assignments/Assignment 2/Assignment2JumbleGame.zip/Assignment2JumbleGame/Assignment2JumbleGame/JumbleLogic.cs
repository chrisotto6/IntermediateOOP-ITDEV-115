﻿/*************************
 * Christopher Otto
 * Jumble Game
 * Logic Class
 * Spring 2014, ITDEV-115
 **************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2JumbleGame
{
    class JumbleLogic
    {
        String[] aryWord = new String[] { "BADGERS", "BREWERS", "BUCKS", "PACKERS", "MILLER", "MARQUETTE", "LAKEFRONT" }; //create array of random words
       
        char[] displayWord; //displayWord string
        string word;  //hidden word

        //Constructor
        public JumbleLogic() //constructor that when called Generates the random number and then scrambles the word from from the array that random number selected
        {
            GenerateRandomNumber();
            ScrambleWord();

        }
        public string HiddenWord //Property assign get property to HiddenWord
        {
            get
            {
                return word;
            }
        }
        public string DisplayWord()//Displays the jumbled word
        {

            string test = null;


            for (int index = 0; index < displayWord.Length; index++) //creates the word from being jumbled
            {
                test = test + displayWord[index];
            }
            return test;

        }
        public void ScrambleWord() //scrambles the word
        {
            int random;
            char temp;
            Random randObj = new Random();

            displayWord = new char[word.Length];  //initializing array

            for (int i = 0; i < word.Length; i++)
            {
                do //we pick a spot does not have a letter.
                    random = randObj.Next(word.Length);

                while (displayWord[random] != 0); //executes while random does not = 0

                temp = word[i];
                displayWord[random] = temp;
            }
        }


        void GenerateRandomNumber() //creates a random Number to pull a word out of the array
        {
            int random;

            Random randObj = new Random(); 

            random = randObj.Next(0, aryWord.Length); 

            word = aryWord[random];

        }

        public bool CompareString(string guess) //compares the strings based on bool being if they are the same the statement is then true
        {
            bool result;

            result = word.Equals(guess);

            return result;
        }
        
    }
   

}
