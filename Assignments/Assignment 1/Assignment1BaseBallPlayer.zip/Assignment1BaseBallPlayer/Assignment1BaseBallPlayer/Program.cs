﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1BaseBallPlayer
{
    class Program
    {
        static void Main(string[] args)
        {
            //Creating the first baseball player as a new BaseBallPlayer and assigning the values to it
            BaseBallPlayer firstBallPlayer = new BaseBallPlayer();
            firstBallPlayer.BattingAvg = ".303";
            firstBallPlayer.FirstName = "Ryan";
            firstBallPlayer.LastName = "Braun";
            firstBallPlayer.Team = "Milwaukee Brewers";

            //Creating the second baseball player as a new BaseBallPlayer and assigning the values to it
            BaseBallPlayer secondBallPlayer = new BaseBallPlayer();
            secondBallPlayer.BattingAvg = ".400";
            secondBallPlayer.FirstName = "Chris";
            secondBallPlayer.LastName = "Otto";
            secondBallPlayer.Team = "Milwaukee Brewers";

            //Calling DisplayInfo on each new BaseBallPlayer to print out the information
            firstBallPlayer.DisplayInfo();
            secondBallPlayer.DisplayInfo();

            //Added so that the application stops to validate the data that was entered and printed
            Console.ReadLine();
        }
    }
}
